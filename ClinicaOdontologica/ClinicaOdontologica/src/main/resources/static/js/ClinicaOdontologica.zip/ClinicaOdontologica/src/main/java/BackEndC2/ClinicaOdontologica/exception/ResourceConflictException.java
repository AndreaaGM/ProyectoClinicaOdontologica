package BackEndC2.ClinicaOdontologica.exception;

public class ResourceConflictException extends Exception{
    public ResourceConflictException(String message) {
        super(message);
    }
}