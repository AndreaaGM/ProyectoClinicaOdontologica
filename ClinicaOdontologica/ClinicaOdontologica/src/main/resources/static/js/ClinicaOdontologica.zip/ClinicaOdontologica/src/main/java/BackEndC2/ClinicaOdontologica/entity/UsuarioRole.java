package BackEndC2.ClinicaOdontologica.entity;

public enum UsuarioRole {
    ROLE_USER, ROLE_ADMIN
}
